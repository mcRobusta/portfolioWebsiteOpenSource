from setuptools import setup

setup(
    name='my_package',
    version='0.1',
    py_modules=['my_module'],
    install_requires=[
        'yfinance',
    ],
)
